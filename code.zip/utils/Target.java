package com.jiang.android.push.utils;

/**
 * Created by jiang on 2016/10/8.
 */

public enum Target {
    MIUI, EMUI, FLYME, JPUSH
}
